test = {'name': 'q8', 'points': 1, 'suites': [{'cases': [{'code': '>>> q8\n2', 'hidden': True, 'locked': False, 'points': 1}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
