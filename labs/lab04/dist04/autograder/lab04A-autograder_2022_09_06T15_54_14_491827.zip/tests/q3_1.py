test = {   'name': 'q3_1',
    'points': None,
    'suites': [   {   'cases': [{'code': ">>> zafon[6]\n'i'", 'failure_message': 'Check that you are using the correct key.', 'hidden': False, 'locked': False, 'points': 1}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
